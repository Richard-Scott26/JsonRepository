﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain.Entities;
using Domain.Interfaces;

namespace Infraestructure.Repository
{
    class BinaryEmpleadoRepository : IEmpleadoModel
    {
        public RAFContext context;
        public int SIZE = 600;
        public void Add(Empleado t)
        {
            try
            {
                context = new RAFContext("Empleado", SIZE);
                context.Create<Empleado>(t);
            }
            catch (Exception) { throw; }
        }

        public void Delete(Empleado t)
        {
            throw new NotImplementedException();
        }

        public Empleado GetById(int id)
        {
            throw new NotImplementedException();
        }

        public List<Empleado> Read()
        {
            throw new NotImplementedException();
        }
    }
}
